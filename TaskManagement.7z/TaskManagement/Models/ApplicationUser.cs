using Microsoft.AspNetCore.Identity;

namespace TaskManagement.Models
{
    public class ApplicationUser : IdentityUser
    {
        // You can add additional properties here if needed
        // For example:
        // public string FirstName { get; set; }
        // public string LastName { get; set; }
    }
}