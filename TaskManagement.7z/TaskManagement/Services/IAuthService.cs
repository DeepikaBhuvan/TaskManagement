using System.Threading.Tasks;
using TaskManagement.Models;

namespace TaskManagement.Services
{
    public interface IAuthService
    {
        Task<UserModel> LoginAsync(string emailOrUsername, string password);
        Task<bool> RegisterAsync(string username, string email, string password);
    }
}