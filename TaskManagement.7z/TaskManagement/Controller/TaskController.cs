using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using TaskManagement.Models;
using TaskManagement.Services;

namespace TaskManagement.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TaskController : ControllerBase
    {
        private readonly ITaskService _taskService;

        public TaskController(ITaskService taskService)
        {
            _taskService = taskService;
        }

        [HttpGet]
        public async Task<IActionResult> GetTasks(int userId)
        {
            var tasks = await _taskService.GetTasksAsync(userId);
            return Ok(tasks);
        }

        [HttpGet("{taskId}")]
        public async Task<IActionResult> GetTask(int taskId, int userId)
        {
            var task = await _taskService.GetTaskByIdAsync(taskId, userId);
            if (task == null)
                return NotFound();
            return Ok(task);
        }

        [HttpPost]
        public async Task<IActionResult> CreateTask([FromBody] TaskModel task)
        {
            var createdTask = await _taskService.CreateTaskAsync(task);
            return CreatedAtAction(nameof(GetTask), new { taskId = createdTask.TaskId }, createdTask);
        }

        [HttpPut("{taskId}")]
        public async Task<IActionResult> UpdateTask(int taskId, [FromBody] TaskModel task)
        {
            if (taskId != task.TaskId)
                return BadRequest();

            var result = await _taskService.UpdateTaskAsync(task);
            if (!result)
                return NotFound();

            return NoContent();
        }

        [HttpDelete("{taskId}")]
        public async Task<IActionResult> DeleteTask(int taskId, int userId)
        {
            var result = await _taskService.DeleteTaskAsync(taskId, userId);
            if (!result)
                return NotFound();

            return NoContent();
        }
    }
}