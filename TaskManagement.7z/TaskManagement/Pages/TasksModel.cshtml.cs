using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Authorization;
using TaskManagement.Services;
using TaskManagement.Models;

namespace TaskManagement.Pages
{
    [Authorize]
    public class TasksModel : PageModel
    {
        private readonly ITaskService _taskService;

        public TasksModel(ITaskService taskService)
        {
            _taskService = taskService;
        }

        public IList<TaskModel> Tasks { get; set; }

        [TempData]
        public string StatusMessage { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            var userId = int.Parse(User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value);
            Tasks = (await _taskService.GetTasksAsync(userId)).ToList();
            return Page();
        }

       public async Task<IActionResult> OnPostAddTaskAsync(string title, string description, DateTime dueDate)
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            var userId = int.Parse(User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value);
            var newTask = new TaskModel
            {
                Title = title,
                Description = description,
                DueDate = dueDate,
                UserId = userId,
                // IsCompleted = false  - Remove this line
            };

            await _taskService.CreateTaskAsync(newTask);
            StatusMessage = "Task added successfully.";
            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostCompleteTaskAsync(int taskId)
        {
            var userId = int.Parse(User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value);
            var task = await _taskService.GetTaskByIdAsync(taskId, userId);
            
            if (task == null)
            {
                return NotFound();
            }

            // task.IsCompleted = true;  - Remove this line
            // Instead, you might want to update the Status if you're using that to track completion
            task.Status = TaskStatusEnum.Completed;  // Assuming you have a 'Completed' status
            await _taskService.UpdateTaskAsync(task);
            StatusMessage = "Task marked as completed.";
            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostDeleteTaskAsync(int taskId)
        {
            var userId = int.Parse(User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value);
            await _taskService.DeleteTaskAsync(taskId, userId);
            StatusMessage = "Task deleted successfully.";
            return RedirectToPage();
        }
    }
}