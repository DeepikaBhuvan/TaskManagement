using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using TaskManagement.Services;

namespace TaskManagement.Pages.Account
{
    public class LoginModel : PageModel
    {
        private readonly IAuthService _authService;
        private readonly ILogger<LoginModel> _logger;
        private readonly HtmlEncoder _htmlEncoder;

        public LoginModel(IAuthService authService, ILogger<LoginModel> logger, HtmlEncoder htmlEncoder)
        {
            _authService = authService;
            _logger = logger;
            _htmlEncoder = htmlEncoder; // This line was missing
        }

        [BindProperty]
        public InputModel Input { get; set; }

        public string ReturnUrl { get; set; }

        [TempData]
        public string ErrorMessage { get; set; }

        public void OnGet(string returnUrl = null)
        {
            ReturnUrl = returnUrl;
        }

        public async Task<IActionResult> OnPostAsync(string returnUrl = null)
        {
            returnUrl ??= Url.Content("~/Tasks"); // Default to the Tasks page

            if (ModelState.IsValid)
            {
                var user = await _authService.LoginAsync(Input.EmailOrUsername, Input.Password);
                if (user != null)
                {
                    _logger.LogInformation("User logged in successfully: {EmailOrUsername}", Input.EmailOrUsername);
                    return LocalRedirect(returnUrl);
                }
                else
                {
                    _logger.LogWarning("Failed login attempt: {EmailOrUsername}", Input.EmailOrUsername);
                    ModelState.AddModelError(string.Empty, _htmlEncoder.Encode("Invalid login attempt. If you haven't registered, please ") +
                        $"<a href='{Url.Page("/Account/Register")}'>register here</a>.");
                }
            }

            return Page();
        }

        public class InputModel
        {
            [Required]
            [Display(Name = "Email or Username")]
            public string EmailOrUsername { get; set; }

            [Required]
            [DataType(DataType.Password)]
            public string Password { get; set; }
        }
    }
}